# Nexo — guia de integração

## 1. Fontes
O app já usa Geist (`--font-geist-sans`) e Geist Mono. O rebranding mantém Geist, mas passa a usar pesos **300/400/500** (não 700/900). Se usar `next/font/google`, carregue `weight: ['300','400','500','600']`.

## 2. globals.css
Substitua `apps/web/src/app/globals.css` por `globals.nexo.css`.
- Mantém `@import "tailwindcss"` e o `@custom-variant dark`.
- Adiciona tokens `--nexo-*` e utilitários `.nexo-*`.
- A seção "Legacy slate overrides" faz as 40+ páginas antigas herdarem o visual Nexo sem editar cada arquivo. Depois, substitua gradualmente `bg-white rounded-2xl border-slate-200` por `nexo-panel` etc.

## 3. Marca
- `Sidebar.tsx` e `AuthShell.tsx`: trocar "SEO Playground" por **NEXO** (letter-spacing 0.1em, peso 500) e o ícone por uma barra vertical `8×20px`, `border-radius:2px`, `background:linear-gradient(180deg,#c2e0ff,#1f6bff)`.
- `settings/page.tsx`: "Leave the name blank to use SEO Playground" → "…to use Nexo".
- `lib/brand.ts`: `DEFAULT_BRAND_COLOR = '#1f6bff'`.

## 4. Shell (layout.tsx)
```tsx
<div className="relative flex h-dvh bg-[var(--nexo-bg)] text-[var(--nexo-text)] font-sans overflow-hidden">
  <div className="nexo-beams" />
  <Sidebar ... />  {/* fundo rgba(3,5,8,.6) + backdrop-blur-xl, border-r var(--nexo-border) */}
  <div className="relative flex-1 flex flex-col min-w-0">
    <header className="h-14 border-b border-[var(--nexo-border)] bg-[rgba(3,5,8,.5)] backdrop-blur-xl ..." />
    <main className="flex-1 overflow-y-auto p-8"><div className="max-w-6xl mx-auto">{children}</div></main>
  </div>
</div>
```

## 5. Paleta de pins do Geo-grid (lib/grid-preferences)
Escala monocromática azul:
- 1–3 → `#c2e0ff` (texto `#030508`, glow `0 0 18px rgba(194,224,255,.6)`)
- 4–10 → `#4da2ff`
- 11–20 → `#1246b8`
- 20+ → `rgba(77,162,255,.1)` com borda `rgba(77,162,255,.4)`

## 6. Referência visual
`Nexo Dashboard.dc.html` (este projeto) — Login, Painel, Rank Tracker, SERP Checker, Local Finder, Geo-Grid, Gastos, Configurações e o template genérico de ferramenta. `Nexo Studio.dc.html` cobre a landing/Studio em `src/`.
